package com.name.foodapp.Utils;

import com.name.foodapp.model.Cart;

import java.util.ArrayList;
import java.util.List;

public class Utils {
    public static List<Cart> cartList = new ArrayList<>();
}
