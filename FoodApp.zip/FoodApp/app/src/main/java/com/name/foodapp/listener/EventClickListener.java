package com.name.foodapp.listener;

import com.name.foodapp.model.Meals;

public interface EventClickListener {
    void onPopularClick(Meals meals);
}
