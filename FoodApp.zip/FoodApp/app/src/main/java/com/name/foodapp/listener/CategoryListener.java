package com.name.foodapp.listener;

import com.name.foodapp.model.Category;

public interface CategoryListener {
    void onCategoryClick(Category category);
}
