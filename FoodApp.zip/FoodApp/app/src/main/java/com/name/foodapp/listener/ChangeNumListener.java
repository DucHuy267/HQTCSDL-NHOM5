package com.name.foodapp.listener;

public interface ChangeNumListener {
    void change();
}
