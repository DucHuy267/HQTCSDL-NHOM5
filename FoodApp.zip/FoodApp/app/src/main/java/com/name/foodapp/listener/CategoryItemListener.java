package com.name.foodapp.listener;

import com.name.foodapp.model.Meals;

public interface CategoryItemListener {
    void onItemClick(Meals meals);

}
